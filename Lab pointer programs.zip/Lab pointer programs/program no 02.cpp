#include <iostream>
using namespace std;
int main() {
    int var = 5;
    int* pointVar;

    
    pointVar = &var;

   
    cout << "var = " << var << endl;

   
    cout << "*pointVar = " << *pointVar << endl
         << endl;

    cout << "Changing value of var to 7:" << endl;

    // change value of var to 7
    var = 7;

    // print var
    cout << "var = " << var << endl;

    // print *pointVar
    cout << "*pointVar = " << *pointVar << endl
         << endl;

    cout << "Changing value of *pointVar to 16:" << endl;

   
    *pointVar = 16;

  
    cout << "var = " << var << endl;

 
    cout << "*pointVar = " << *pointVar << endl;
    return 0;
}