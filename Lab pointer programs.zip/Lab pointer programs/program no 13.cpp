
#include <iostream>
#include<conio.h>

using namespace std;

#define MAX_SIZE 5

int main() {

   // Declare Variables
   int var[5];
   int i = 0, sum = 0;

   //Pointer Variable Declaration for Integer Data Type 
   int *pt;

   cout << "Pointer Example C++ Program : Read, Print and Sum of Integer Pointer and Array \n";

   //& takes the address of var , Here now pt == &var, so *pt == var
   pt = &var[0];

   cout << "Enter " << MAX_SIZE << " Elements : \n";

   while (i < MAX_SIZE) {
      // pt + i is increasing Address value based on Data Type
      cin>>*pt;
      i++;
      pt++;
   }

   i = 0;
   pt = &var[0];
   cout << "\nPrint Elements:\n";
   while (i < MAX_SIZE) {
      i++;

      // Calculate sum using pointer
      cout << *pt << "\t";
      sum = sum + *pt;

      // pt++ is increasing Address value based on Data Type
      pt++;
   }

   cout << "\nSum of Array : " << sum;

   getch();
   return 0;
}